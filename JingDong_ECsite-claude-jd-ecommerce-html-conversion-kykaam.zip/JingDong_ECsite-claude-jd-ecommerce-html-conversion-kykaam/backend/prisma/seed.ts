import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// API側のZodバリデーション（categoryId/idはuuid()必須）を満たすため、
// シードの固定ID（冪等なupsertキー）は有効なUUID形式にする。
const CATEGORY_ID = {
  electronics: '10000000-0000-4000-8000-000000000001',
  phones: '10000000-0000-4000-8000-000000000002',
  laptops: '10000000-0000-4000-8000-000000000003',
  home: '10000000-0000-4000-8000-000000000004',
  kitchen: '10000000-0000-4000-8000-000000000005',
  fashion: '10000000-0000-4000-8000-000000000006',
};
const BANNER_ID = {
  banner1: '20000000-0000-4000-8000-000000000001',
  banner2: '20000000-0000-4000-8000-000000000002',
};

async function main() {
  const adminEmail = process.env.ADMIN_EMAIL ?? 'admin@jdec.example.com';
  const adminPassword = process.env.ADMIN_PASSWORD ?? 'Admin@12345';

  const adminPasswordHash = await bcrypt.hash(adminPassword, 12);
  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      passwordHash: adminPasswordHash,
      name: '管理者',
      role: 'ADMIN',
    },
  });

  const demoPasswordHash = await bcrypt.hash('Demo@12345', 12);
  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@jdec.example.com' },
    update: {},
    create: {
      email: 'demo@jdec.example.com',
      passwordHash: demoPasswordHash,
      name: 'デモ会員',
      role: 'USER',
      cart: { create: {} },
    },
  });

  // カテゴリ
  const electronics = await prisma.category.upsert({
    where: { id: CATEGORY_ID.electronics },
    update: {},
    create: { id: CATEGORY_ID.electronics, name: '家電・PC', sortOrder: 1 },
  });
  const phones = await prisma.category.upsert({
    where: { id: CATEGORY_ID.phones },
    update: {},
    create: { id: CATEGORY_ID.phones, name: 'スマートフォン', parentId: electronics.id, sortOrder: 1 },
  });
  const laptops = await prisma.category.upsert({
    where: { id: CATEGORY_ID.laptops },
    update: {},
    create: { id: CATEGORY_ID.laptops, name: 'ノートPC', parentId: electronics.id, sortOrder: 2 },
  });
  const home = await prisma.category.upsert({
    where: { id: CATEGORY_ID.home },
    update: {},
    create: { id: CATEGORY_ID.home, name: '生活雑貨', sortOrder: 2 },
  });
  const kitchen = await prisma.category.upsert({
    where: { id: CATEGORY_ID.kitchen },
    update: {},
    create: { id: CATEGORY_ID.kitchen, name: 'キッチン用品', parentId: home.id, sortOrder: 1 },
  });
  const fashion = await prisma.category.upsert({
    where: { id: CATEGORY_ID.fashion },
    update: {},
    create: { id: CATEGORY_ID.fashion, name: 'ファッション', sortOrder: 3 },
  });

  const products = [
    {
      sku: 'PH-1001',
      name: 'スマートフォン X10 Pro 256GB',
      description: '6.7インチ有機EL、5000mAhバッテリー、トリプルカメラ搭載のハイエンドスマートフォン。',
      brand: 'NovaTech',
      categoryId: phones.id,
      price: 89800,
      originalPrice: 99800,
      stock: 45,
      images: ['https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800'],
    },
    {
      sku: 'PH-1002',
      name: 'スマートフォン Lite 5G 128GB',
      description: 'コストパフォーマンスに優れた5G対応スマートフォン。',
      brand: 'NovaTech',
      categoryId: phones.id,
      price: 39800,
      originalPrice: 45800,
      stock: 80,
      images: ['https://images.unsplash.com/photo-1592286927505-1def25115558?w=800'],
    },
    {
      sku: 'PC-2001',
      name: 'ノートPC UltraBook 14 (Core i7/16GB/512GB)',
      description: '軽量1.2kg、薄型ボディのビジネスノートPC。',
      brand: 'CompuMax',
      categoryId: laptops.id,
      price: 128000,
      originalPrice: 148000,
      stock: 25,
      images: ['https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800'],
    },
    {
      sku: 'PC-2002',
      name: 'ゲーミングノートPC G16 (RTX/32GB)',
      description: '高リフレッシュレート144Hzディスプレイ搭載のゲーミングノートPC。',
      brand: 'CompuMax',
      categoryId: laptops.id,
      price: 218000,
      stock: 15,
      images: ['https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=800'],
    },
    {
      sku: 'KT-3001',
      name: 'ステンレス電気ケトル 1.2L',
      description: '約3分で沸騰、自動電源オフ機能付き。',
      brand: 'HomeLife',
      categoryId: kitchen.id,
      price: 3980,
      originalPrice: 4980,
      stock: 120,
      images: ['https://images.unsplash.com/photo-1585515320310-259814833e62?w=800'],
    },
    {
      sku: 'KT-3002',
      name: 'ノンフライヤー 5.5L 大容量',
      description: '油を使わずヘルシーに揚げ物調理ができる家庭用ノンフライヤー。',
      brand: 'HomeLife',
      categoryId: kitchen.id,
      price: 12800,
      stock: 60,
      images: ['https://images.unsplash.com/photo-1585237017125-24baf8d7406f?w=800'],
    },
    {
      sku: 'FS-4001',
      name: 'カジュアルダウンジャケット メンズ',
      description: '軽量で保温性の高いダウンジャケット。防風・撥水加工。',
      brand: 'UrbanWear',
      categoryId: fashion.id,
      price: 8900,
      originalPrice: 12800,
      stock: 90,
      images: ['https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800'],
    },
    {
      sku: 'FS-4002',
      name: 'レディース ニットセーター',
      description: '柔らかな肌触りの秋冬向けニットセーター。',
      brand: 'UrbanWear',
      categoryId: fashion.id,
      price: 4500,
      stock: 150,
      images: ['https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=800'],
    },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { sku: p.sku },
      update: {},
      create: p,
    });
  }

  await prisma.banner.upsert({
    where: { id: BANNER_ID.banner1 },
    update: {},
    create: {
      id: BANNER_ID.banner1,
      imageUrl: 'https://images.unsplash.com/photo-1607082349566-187342175e2f?w=1200',
      title: '新生活応援セール開催中',
      sortOrder: 1,
    },
  });
  await prisma.banner.upsert({
    where: { id: BANNER_ID.banner2 },
    update: {},
    create: {
      id: BANNER_ID.banner2,
      imageUrl: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1200',
      title: '家電まとめ買いキャンペーン',
      sortOrder: 2,
    },
  });

  await prisma.coupon.upsert({
    where: { code: 'WELCOME1000' },
    update: {},
    create: {
      code: 'WELCOME1000',
      description: '新規会員限定 1,000円引きクーポン',
      discountType: 'FIXED',
      discountValue: 1000,
      minAmount: 5000,
      totalQuantity: 1000,
      autoGrantOnSignup: true,
      startsAt: new Date(),
      expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
    },
  });
  await prisma.coupon.upsert({
    where: { code: 'SAVE10PCT' },
    update: {},
    create: {
      code: 'SAVE10PCT',
      description: '全品10%OFF（上限2,000円）',
      discountType: 'PERCENTAGE',
      discountValue: 10,
      maxDiscount: 2000,
      minAmount: 3000,
      totalQuantity: 500,
      startsAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    },
  });

  console.log('シードデータ投入完了');
  console.log(`管理者アカウント: ${adminEmail} / ${adminPassword}`);
  console.log(`デモ会員アカウント: demo@jdec.example.com / Demo@12345 (userId=${demoUser.id})`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
