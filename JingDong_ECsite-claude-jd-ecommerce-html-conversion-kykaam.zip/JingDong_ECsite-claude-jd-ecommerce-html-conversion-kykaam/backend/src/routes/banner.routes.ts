import { Router } from 'express';
import { prisma } from '../config/prisma';
import { catchAsync } from '../utils/catchAsync';
import { ok } from '../utils/apiResponse';

const router = Router();

router.get(
  '/',
  catchAsync(async (_req, res) => {
    res.set('Cache-Control', 'public, max-age=60');
    const banners = await prisma.banner.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } });
    ok(res, banners);
  }),
);

export default router;
