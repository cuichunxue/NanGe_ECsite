import { Router } from 'express';
import { prisma } from '../config/prisma';
import { requireAuth, requireAdmin } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { catchAsync } from '../utils/catchAsync';
import { ok } from '../utils/apiResponse';
import { ApiError } from '../utils/apiError';
import { idParamSchema } from '../validators/common';
import { createCouponSchema, updateCouponSchema } from '../validators/couponValidators';

const router = Router();

router.get(
  '/available',
  requireAuth,
  catchAsync(async (req, res) => {
    const now = new Date();
    const coupons = await prisma.coupon.findMany({
      where: { isActive: true, startsAt: { lte: now }, expiresAt: { gte: now } },
      orderBy: { createdAt: 'desc' },
    });
    const claimed = await prisma.userCoupon.findMany({ where: { userId: req.user!.id } });
    const claimedIds = new Set(claimed.map((c) => c.couponId));
    ok(
      res,
      coupons.map((c) => ({ ...c, claimed: claimedIds.has(c.id) })),
    );
  }),
);

router.get(
  '/mine',
  requireAuth,
  catchAsync(async (req, res) => {
    const userCoupons = await prisma.userCoupon.findMany({
      where: { userId: req.user!.id },
      include: { coupon: true },
      orderBy: { createdAt: 'desc' },
    });
    ok(res, userCoupons);
  }),
);

router.post(
  '/:id/claim',
  requireAuth,
  validate(idParamSchema),
  catchAsync(async (req, res) => {
    const coupon = await prisma.coupon.findUnique({ where: { id: req.params.id } });
    if (!coupon || !coupon.isActive || coupon.expiresAt < new Date()) {
      throw ApiError.badRequest('クーポンが利用できません', 'INVALID_COUPON');
    }
    // 「取得済み」は自分自身の状態を伝える情報なので、配布上限チェックより先に判定し、
    // 上限到達後に自分の既取得クーポンへ再アクセスしても誤解を招くメッセージにならないようにする
    const existing = await prisma.userCoupon.findUnique({
      where: { userId_couponId: { userId: req.user!.id, couponId: coupon.id } },
    });
    if (existing) throw ApiError.conflict('既に取得済みのクーポンです', 'ALREADY_CLAIMED');
    if (coupon.totalQuantity > 0 && coupon.claimedCount >= coupon.totalQuantity) {
      throw ApiError.conflict('クーポンの配布数が上限に達しました', 'COUPON_EXHAUSTED');
    }

    const [userCoupon] = await prisma.$transaction([
      prisma.userCoupon.create({ data: { userId: req.user!.id, couponId: coupon.id } }),
      prisma.coupon.update({ where: { id: coupon.id }, data: { claimedCount: { increment: 1 } } }),
    ]);
    ok(res, userCoupon, 201);
  }),
);

// --- 管理者用 ---
router.get(
  '/',
  requireAuth,
  requireAdmin,
  catchAsync(async (_req, res) => {
    const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: 'desc' } });
    ok(res, coupons);
  }),
);

router.post(
  '/',
  requireAuth,
  requireAdmin,
  validate(createCouponSchema),
  catchAsync(async (req, res) => {
    const coupon = await prisma.coupon.create({ data: req.body });
    ok(res, coupon, 201);
  }),
);

router.patch(
  '/:id',
  requireAuth,
  requireAdmin,
  validate(updateCouponSchema),
  catchAsync(async (req, res) => {
    const coupon = await prisma.coupon.update({ where: { id: req.params.id }, data: req.body });
    ok(res, coupon);
  }),
);

router.delete(
  '/:id',
  requireAuth,
  requireAdmin,
  validate(idParamSchema),
  catchAsync(async (req, res) => {
    await prisma.coupon.update({ where: { id: req.params.id }, data: { isActive: false } });
    ok(res, { message: '無効化しました' });
  }),
);

export default router;
