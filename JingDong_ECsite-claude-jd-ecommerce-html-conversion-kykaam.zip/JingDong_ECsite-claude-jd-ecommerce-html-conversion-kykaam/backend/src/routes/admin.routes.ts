import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { requireAuth, requireAdmin } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { catchAsync } from '../utils/catchAsync';
import { ok, okPaginated } from '../utils/apiResponse';
import { ApiError } from '../utils/apiError';
import { idParamSchema, paginationQuery } from '../validators/common';
import { updateOrderStatusSchema, listOrdersQuerySchema } from '../validators/orderValidators';
import * as orderService from '../services/order.service';
import { toPublicUser } from '../services/auth.service';

const router = Router();
router.use(requireAuth, requireAdmin);

// --- ダッシュボード ---
router.get(
  '/dashboard',
  catchAsync(async (_req, res) => {
    const [userCount, orderCount, productCount, lowStockCount, revenueAgg, statusGroups] = await Promise.all([
      prisma.user.count({ where: { role: 'USER' } }),
      prisma.order.count(),
      prisma.product.count({ where: { status: 'ON_SALE' } }),
      prisma.product.count({ where: { stock: { lte: 10 }, status: 'ON_SALE' } }),
      prisma.order.aggregate({
        where: { status: { in: ['PAID', 'SHIPPED', 'COMPLETED'] } },
        _sum: { totalAmount: true },
      }),
      prisma.order.groupBy({ by: ['status'], _count: { status: true } }),
    ]);

    const recentOrders = await prisma.order.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { user: { select: { name: true, email: true } } },
    });

    ok(res, {
      userCount,
      orderCount,
      productCount,
      lowStockCount,
      totalRevenue: revenueAgg._sum.totalAmount ?? 0,
      ordersByStatus: statusGroups.map((g) => ({ status: g.status, count: g._count.status })),
      recentOrders,
    });
  }),
);

// --- 会員管理 ---
router.get(
  '/users',
  validate(z.object({ query: paginationQuery.extend({ keyword: z.string().optional() }) })),
  catchAsync(async (req, res) => {
    const { page, pageSize, keyword } = req.query as unknown as { page: number; pageSize: number; keyword?: string };
    const where = keyword
      ? { OR: [{ email: { contains: keyword, mode: 'insensitive' as const } }, { name: { contains: keyword, mode: 'insensitive' as const } }] }
      : {};
    const [items, total] = await Promise.all([
      prisma.user.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize }),
      prisma.user.count({ where }),
    ]);
    okPaginated(res, items.map(toPublicUser), { page, pageSize, total });
  }),
);

router.patch(
  '/users/:id/status',
  validate(z.object({ params: idParamSchema.shape.params, body: z.object({ status: z.enum(['ACTIVE', 'SUSPENDED']) }) })),
  catchAsync(async (req, res) => {
    const user = await prisma.user.update({ where: { id: req.params.id }, data: { status: req.body.status } });
    if (req.body.status === 'SUSPENDED') {
      // 凍結を即座に有効化するため、既存のリフレッシュトークンを全て失効させる
      // （既発行のアクセストークンは短命のため、最長でもその有効期限内に失効する）
      await prisma.refreshToken.deleteMany({ where: { userId: user.id } });
    }
    ok(res, toPublicUser(user));
  }),
);

// --- 注文管理 ---
router.get(
  '/orders',
  validate(listOrdersQuerySchema),
  catchAsync(async (req, res) => {
    const { page, pageSize, status } = req.query as unknown as { page: number; pageSize: number; status?: string };
    const where = status ? { status: status as never } : {};
    const [items, total] = await Promise.all([
      prisma.order.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { items: true, user: { select: { id: true, name: true, email: true } } },
      }),
      prisma.order.count({ where }),
    ]);
    okPaginated(res, items, { page, pageSize, total });
  }),
);

router.get(
  '/orders/:id',
  validate(idParamSchema),
  catchAsync(async (req, res) => {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { items: true, user: { select: { id: true, name: true, email: true } } },
    });
    if (!order) throw ApiError.notFound('注文が見つかりません');
    ok(res, order);
  }),
);

router.patch(
  '/orders/:id/status',
  validate(updateOrderStatusSchema),
  catchAsync(async (req, res) => {
    const order = await orderService.adminUpdateStatus(req.params.id, req.body.status);
    ok(res, order);
  }),
);

// --- バナー管理 ---
const bannerBody = z.object({
  imageUrl: z.string().url(),
  linkUrl: z.string().url().optional().or(z.literal('')),
  title: z.string().max(100).optional(),
  sortOrder: z.number().int().optional(),
  isActive: z.boolean().optional(),
});

router.get(
  '/banners',
  catchAsync(async (_req, res) => {
    const banners = await prisma.banner.findMany({ orderBy: { sortOrder: 'asc' } });
    ok(res, banners);
  }),
);

router.post(
  '/banners',
  validate(z.object({ body: bannerBody })),
  catchAsync(async (req, res) => {
    const banner = await prisma.banner.create({ data: req.body });
    ok(res, banner, 201);
  }),
);

router.patch(
  '/banners/:id',
  validate(z.object({ body: bannerBody.partial(), params: idParamSchema.shape.params })),
  catchAsync(async (req, res) => {
    const banner = await prisma.banner.update({ where: { id: req.params.id }, data: req.body });
    ok(res, banner);
  }),
);

router.delete(
  '/banners/:id',
  validate(idParamSchema),
  catchAsync(async (req, res) => {
    await prisma.banner.delete({ where: { id: req.params.id } });
    ok(res, { message: '削除しました' });
  }),
);

export default router;
