import { z } from 'zod';

const couponBody = z.object({
  code: z.string().min(3).max(30),
  description: z.string().max(200).optional(),
  discountType: z.enum(['FIXED', 'PERCENTAGE']),
  discountValue: z.number().positive(),
  minAmount: z.number().min(0).default(0),
  maxDiscount: z.number().positive().optional(),
  totalQuantity: z.number().int().min(0).default(0),
  autoGrantOnSignup: z.boolean().default(false),
  startsAt: z.coerce.date(),
  expiresAt: z.coerce.date(),
});

export const createCouponSchema = z.object({ body: couponBody });
export const updateCouponSchema = z.object({
  body: couponBody.partial().extend({ isActive: z.boolean().optional() }),
  params: z.object({ id: z.string().uuid() }),
});
