import { initLayout, initAdminLayout } from '../layout.js';
import { requireAdmin } from '../guards.js';
import { couponApi, getErrorMessage } from '../api.js';
import { formatDateTime, escapeHtml } from '../format.js';

if (requireAdmin('../')) {
  initLayout({ base: '../' });
  initAdminLayout('coupons.html');

  function load() {
    couponApi.adminList().then((res) => {
      document.getElementById('coupon-rows').innerHTML = res.data
        .map(
          (c) => `
          <tr class="border-t" data-coupon-id="${c.id}">
            <td class="p-3">
              <p>${escapeHtml(c.code)}</p>
              <p class="text-xs text-gray-400">${escapeHtml(c.description ?? '')}</p>
            </td>
            <td class="p-3">${c.discountType === 'FIXED' ? `¥${c.discountValue}` : `${c.discountValue}%`}</td>
            <td class="p-3">${c.claimedCount} / ${c.totalQuantity || '∞'}</td>
            <td class="p-3 text-gray-400">${formatDateTime(c.expiresAt)}</td>
            <td class="p-3"><span class="rounded px-2 py-0.5 text-xs ${c.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}">${c.isActive ? '有効' : '無効'}</span></td>
            <td class="p-3">${c.isActive ? '<button data-action="deactivate" class="text-red-500 hover:underline">無効化</button>' : ''}</td>
          </tr>
        `,
        )
        .join('');
      document.querySelectorAll('[data-coupon-id]').forEach((row) => {
        row.querySelector('[data-action="deactivate"]')?.addEventListener('click', async () => {
          await couponApi.remove(row.dataset.couponId);
          load();
        });
      });
    });
  }

  document.getElementById('toggle-form-btn').addEventListener('click', () => {
    const form = document.getElementById('coupon-form');
    const hidden = form.classList.toggle('hidden');
    form.classList.toggle('grid', !hidden);
    document.getElementById('toggle-form-btn').textContent = hidden ? '+ 新規クーポン発行' : '閉じる';
  });

  document.getElementById('coupon-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorMsg = document.getElementById('error-msg');
    errorMsg.classList.add('hidden');
    try {
      const maxDiscount = document.getElementById('max-discount').value;
      await couponApi.create({
        code: document.getElementById('code').value,
        description: document.getElementById('description').value || undefined,
        discountType: document.getElementById('discount-type').value,
        discountValue: Number(document.getElementById('discount-value').value),
        minAmount: Number(document.getElementById('min-amount').value || 0),
        maxDiscount: maxDiscount ? Number(maxDiscount) : undefined,
        totalQuantity: Number(document.getElementById('total-quantity').value || 0),
        autoGrantOnSignup: document.getElementById('auto-grant').checked,
        startsAt: new Date(document.getElementById('starts-at').value).toISOString(),
        expiresAt: new Date(document.getElementById('expires-at').value).toISOString(),
      });
      e.target.reset();
      document.getElementById('coupon-form').classList.add('hidden');
      document.getElementById('coupon-form').classList.remove('grid');
      document.getElementById('toggle-form-btn').textContent = '+ 新規クーポン発行';
      load();
    } catch (err) {
      errorMsg.textContent = getErrorMessage(err);
      errorMsg.classList.remove('hidden');
    }
  });

  load();
}
