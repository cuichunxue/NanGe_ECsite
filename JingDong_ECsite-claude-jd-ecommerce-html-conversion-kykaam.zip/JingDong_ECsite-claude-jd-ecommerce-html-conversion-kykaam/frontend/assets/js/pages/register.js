import { initLayout } from '../layout.js';
import { Auth } from '../auth.js';
import { authApi, getErrorMessage } from '../api.js';
import { escapeHtml } from '../format.js';

initLayout({ base: '' });

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errorMsg = document.getElementById('error-msg');
  errorMsg.classList.add('hidden');
  const submitBtn = document.getElementById('submit-btn');
  submitBtn.disabled = true;
  submitBtn.textContent = '登録中…';
  try {
    const form = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      password: document.getElementById('password').value,
    };
    const res = await authApi.register(form);
    const { user, accessToken, refreshToken, grantedCoupons } = res.data;
    Auth.setAuth(user, accessToken, refreshToken);
    if (grantedCoupons && grantedCoupons.length > 0) {
      document.getElementById('form-view').classList.add('hidden');
      const successView = document.getElementById('success-view');
      successView.classList.remove('hidden');
      successView.classList.add('flex');
      document.getElementById('granted-coupons').innerHTML = grantedCoupons
        .map(
          (c) => `
          <div class="rounded border border-brand-200 bg-brand-50 p-3 text-left">
            <p class="font-bold text-brand-700">${escapeHtml(c.code)}</p>
            <p class="text-sm text-brand-600">${escapeHtml(c.description ?? '')}</p>
          </div>
        `,
        )
        .join('');
    } else {
      location.href = 'index.html';
    }
  } catch (err) {
    errorMsg.textContent = getErrorMessage(err, '登録に失敗しました');
    errorMsg.classList.remove('hidden');
    submitBtn.disabled = false;
    submitBtn.textContent = '登録する';
  }
});
