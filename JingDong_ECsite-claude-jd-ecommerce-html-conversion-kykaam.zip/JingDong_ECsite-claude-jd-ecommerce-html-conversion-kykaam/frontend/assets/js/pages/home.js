import { initLayout } from '../layout.js';
import { bannerApi, categoryApi, productApi } from '../api.js';
import { renderProductGrid } from '../components.js';
import { getRecentlyViewed } from '../recentlyViewed.js';
import { escapeHtml, safeUrl } from '../format.js';

initLayout({ base: '' });

bannerApi.list().then((res) => {
  const banners = res.data;
  if (banners.length === 0) return;
  const wrap = document.getElementById('banners');
  const track = document.getElementById('banners-track');
  wrap.classList.remove('hidden');
  track.innerHTML = banners
    .map(
      (b) => `
      <a href="${escapeHtml(safeUrl(b.linkUrl ?? '#'))}" class="relative block h-56 w-full shrink-0 overflow-hidden rounded-lg sm:h-72">
        <img src="${escapeHtml(b.imageUrl)}" alt="${escapeHtml(b.title ?? '')}" class="h-full w-full object-cover" />
        ${b.title ? `<div class="absolute inset-x-0 bottom-0 bg-black/40 px-4 py-2 text-lg font-bold text-white">${escapeHtml(b.title)}</div>` : ''}
      </a>
    `,
    )
    .join('');
});

categoryApi.list().then((res) => {
  const grid = document.getElementById('categories-grid');
  grid.innerHTML = res.data
    .map(
      (c) => `
      <a href="products.html?categoryId=${encodeURIComponent(c.id)}" class="card flex flex-col items-center gap-2 p-4 text-center hover:shadow-md">
        <span class="text-2xl">🛍️</span>
        <span class="text-sm text-gray-700">${escapeHtml(c.name)}</span>
      </a>
    `,
    )
    .join('');
});

productApi.list({ sort: 'newest', pageSize: 10 }).then((res) => {
  renderProductGrid(document.getElementById('newest-grid'), res.data);
});

productApi.list({ sort: 'sales', pageSize: 10 }).then((res) => {
  renderProductGrid(document.getElementById('popular-grid'), res.data);
});

const viewedIds = getRecentlyViewed();
if (viewedIds.length > 0) {
  productApi.byIds(viewedIds).then((res) => {
    if (res.data.length === 0) return;
    document.getElementById('recently-viewed-section').classList.remove('hidden');
    renderProductGrid(document.getElementById('recently-viewed-grid'), res.data);
  });
}
