import { initLayout, initAdminLayout } from '../layout.js';
import { requireAdmin } from '../guards.js';
import { bannerApi, getErrorMessage } from '../api.js';
import { escapeHtml } from '../format.js';

if (requireAdmin('../')) {
  initLayout({ base: '../' });
  initAdminLayout('banners.html');

  function load() {
    bannerApi.adminList().then((res) => {
      document.getElementById('banner-list').innerHTML = res.data
        .map(
          (b) => `
          <div class="card flex items-center gap-4 p-3" data-banner-id="${b.id}">
            <img src="${escapeHtml(b.imageUrl)}" class="h-16 w-28 rounded object-cover" />
            <div class="flex-1">
              <p class="text-sm font-medium">${escapeHtml(b.title ?? '')}</p>
              <p class="text-xs text-gray-400">順序: ${b.sortOrder}</p>
            </div>
            <button data-action="toggle" class="text-sm text-brand-500 hover:underline">${b.isActive ? '非表示にする' : '表示する'}</button>
            <button data-action="remove" class="text-sm text-red-500 hover:underline">削除</button>
          </div>
        `,
        )
        .join('');

      document.querySelectorAll('[data-banner-id]').forEach((row) => {
        const b = res.data.find((item) => item.id === row.dataset.bannerId);
        row.querySelector('[data-action="toggle"]').addEventListener('click', async () => {
          await bannerApi.update(b.id, { isActive: !b.isActive });
          load();
        });
        row.querySelector('[data-action="remove"]').addEventListener('click', async () => {
          if (!confirm('このバナーを削除しますか？')) return;
          await bannerApi.remove(b.id);
          load();
        });
      });
    });
  }

  document.getElementById('banner-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorMsg = document.getElementById('error-msg');
    errorMsg.classList.add('hidden');
    try {
      await bannerApi.create({
        imageUrl: document.getElementById('image-url').value,
        title: document.getElementById('title').value || undefined,
        linkUrl: document.getElementById('link-url').value || undefined,
        sortOrder: Number(document.getElementById('sort-order').value || 0),
      });
      e.target.reset();
      document.getElementById('sort-order').value = '0';
      load();
    } catch (err) {
      errorMsg.textContent = getErrorMessage(err);
      errorMsg.classList.remove('hidden');
    }
  });

  load();
}
