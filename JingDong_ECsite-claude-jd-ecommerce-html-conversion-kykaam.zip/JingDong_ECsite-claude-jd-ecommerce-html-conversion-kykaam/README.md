# JingDong EC — 小規模事業者向けオリジナルECサイト

京東（JD.com）のような総合ECサイトの主要機能を、小〜中規模事業者が安心・簡単・効率的に運用できる規模でオリジナル実装したフルスタックECプラットフォームです。

- 要件定義書: [`docs/requirements.md`](docs/requirements.md)
- バックエンド: Node.js / Express / TypeScript / Prisma / PostgreSQL
- フロントエンド: 素のHTML / CSS / JavaScript（ビルド不要、ES Modules。Tailwind CSSはCDN経由で利用）
- 認証: JWT（アクセストークン + リフレッシュトークン）

## 主な機能

- 会員登録・ログイン・プロフィール・複数配送先住所管理・パスワード再設定
- 商品検索・絞り込み・並び替え・カテゴリ階層・在庫僅少バッジ
- カート・チェックアウト・クーポン取得/適用・モック決済
- 注文管理（支払い待ち→支払済み→発送済み→受取完了[購入者自身で確認可能]→レビュー投稿、キャンセル/返金）
- レビュー・評価、お気に入り
- 管理画面（ダッシュボード、商品/カテゴリ/注文/会員/クーポン/レビュー/バナー管理、コード分割で高速読み込み）
- 特定商取引法に基づく表示ページ（日本国内EC運営の法定表示、フッターから常時アクセス可）

詳細は要件定義書を参照してください。

## ディレクトリ構成

```
JingDong_ECsite/
├── docs/requirements.md   # 要件定義書
├── backend/                # Express API サーバー
│   ├── prisma/schema.prisma
│   ├── prisma/seed.ts
│   └── src/
└── frontend/                # 素のHTML/CSS/JavaScriptによるマルチページサイト
    ├── *.html               # 購入者向け画面（トップ、商品一覧/詳細、カート、注文 等）
    ├── admin/*.html         # 管理画面
    ├── assets/js/           # ESモジュール（API通信・共通レイアウト・各画面ロジック）
    ├── assets/css/          # 共通スタイル
    └── server.js            # 依存パッケージ不要の開発用静的サーバー
```

本プロジェクトはコンテナ基盤（Docker等）を使わず、Node.js / PostgreSQLをホストに直接インストールして動かす構成です。

## セットアップ（開発環境）

### 1. PostgreSQLを用意

```bash
# 例: ローカルPostgreSQLにDB/ユーザーを作成
createuser jdec --pwprompt
createdb jdec -O jdec
```

### 2. バックエンド

```bash
cd backend
cp .env.example .env   # 必要に応じて値を編集（DATABASE_URL, JWTシークレット等）
npm install
npm run prisma:migrate:dev   # マイグレーション適用
npm run seed                 # サンプルデータ投入（管理者/デモ会員/商品/カテゴリ/バナー/クーポン）
npm run dev                  # http://localhost:4000
```

### 3. フロントエンド

ビルド不要の素のHTML/JavaScriptです。`frontend/assets/js/config.js` の `API_BASE_URL` がバックエンドのURL（既定値 `http://localhost:4000/api`）を指しているため、バックエンドの `CORS_ORIGIN` は下記サーバーの既定ポート `http://localhost:5173` のままで動作します。

```bash
cd frontend
npm run dev                  # http://localhost:5173 で静的配信（依存パッケージ不要）
```

`npm run dev` は Node.js 標準機能のみで実装した簡易サーバー（`server.js`）を起動します。任意の静的ファイルサーバー（`npx serve`、`python -m http.server` 等）でも代替可能です。

### デモアカウント（シード投入済み）

| 種別 | メールアドレス | パスワード |
|---|---|---|
| 管理者 | admin@jdec.example.com | Admin@12345 |
| 一般会員 | demo@jdec.example.com | Demo@12345 |

本番運用時は `.env` の `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET` / `ADMIN_PASSWORD` を必ず変更してください。

## 本番運用（参考）

```bash
# バックエンド
cd backend
npm install
npm run build
npm run prisma:migrate   # prisma migrate deploy
npm start                 # node dist/index.js

# フロントエンド（ビルド不要。frontend/ 配下を任意のWebサーバー・CDNでそのまま配信する）
# 配信前に assets/js/config.js の API_BASE_URL を本番バックエンドのURLに変更すること
cd frontend
npm start                  # 動作確認用に簡易サーバーで配信する場合
```

## テスト

```bash
cd backend
npm test        # vitest + supertest によるAPIテスト
npx tsc --noEmit  # 型チェック
```

フロントエンドはビルドや型チェックを必要としない素のHTML/JavaScriptです。`npm run dev` でサーバーを起動し、ブラウザで主要な画面・操作を確認してください。

## セキュリティ設計の要点

- パスワードは bcrypt でハッシュ化して保存
- JWT（アクセス短命 + リフレッシュ）による認証、フロントエンドのfetchラッパーで401時に自動リフレッシュ
- 全APIエンドポイントでZodによる入力バリデーション
- Prisma ORMによりSQLインジェクションを防止
- Helmet + CORS許可オリジン限定 + 認証系・注文系レート制限
- 管理者APIはRBACミドルウェア (`requireAdmin`) で保護
- パスワード再設定トークンはハッシュ化保存・30分有効・使い切り。アカウント有無に関わらず同一レスポンスとしユーザー列挙を防止
- バックエンドは `/api/health`（liveness）と `/api/health/ready`（DB疎通込みreadiness）を提供し、未捕捉例外はログ出力の上で安全にプロセスを終了

## ライセンス・注意事項

本プロジェクトは学習・自社利用目的のオリジナル実装であり、京東(JD.com)の商標・ブランド資産・デザインは一切使用していません。
